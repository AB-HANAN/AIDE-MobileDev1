import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

class RobotLiveFeed extends StatefulWidget {
  const RobotLiveFeed({
    super.key,
    required this.baseUrl,
    this.height = 260,
    this.demoMode = false,
  });

  final String baseUrl;
  final double height;
  final bool demoMode;

  @override
  State<RobotLiveFeed> createState() => _RobotLiveFeedState();
}

class _RobotLiveFeedState extends State<RobotLiveFeed> {
  bool _streamFailed = false;

  String get _feedUrl {
    final trimmed = widget.baseUrl.trim();
    if (trimmed.isEmpty) return '';
    return '$trimmed/video_feed';
  }

  @override
  Widget build(BuildContext context) {
    final showPlaceholder = widget.demoMode || _streamFailed || _feedUrl.isEmpty;

    return Container(
      height: widget.height,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: const Color(0xFF090B13),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
        ),
      ),
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (!showPlaceholder)
            Image.network(
              _feedUrl,
              fit: BoxFit.cover,
              gaplessPlayback: true,
              errorBuilder: (_, __, ___) {
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (!mounted) return;
                  setState(() {
                    _streamFailed = true;
                  });
                });
                return const SizedBox.shrink();
              },
              loadingBuilder: (context, child, progress) {
                if (progress == null) return child;
                return _buildPlaceholder(
                  title: 'Connecting to live camera...',
                  subtitle: _feedUrl,
                  icon: Icons.wifi_find_rounded,
                  showSpinner: true,
                );
              },
            ),

          if (showPlaceholder)
            _buildPlaceholder(
              title: widget.demoMode
                  ? 'Demo camera preview'
                  : 'Live feed unavailable',
              subtitle: widget.demoMode
                  ? 'Skip mode is active. Connect to Jetson to view the real stream.'
                  : (_feedUrl.isEmpty
                      ? 'No base URL available for the camera feed.'
                      : _feedUrl),
              icon: widget.demoMode
                  ? Icons.videocam_rounded
                  : Icons.videocam_off_rounded,
            ),

          Positioned(
            top: 14,
            left: 14,
            child: _pill(
              icon: widget.demoMode
                  ? Icons.play_circle_outline_rounded
                  : (_streamFailed ? Icons.error_outline_rounded : Icons.circle),
              text: widget.demoMode
                  ? 'Demo'
                  : (_streamFailed ? 'Offline' : 'Live'),
              accent: widget.demoMode
                  ? const Color(0xFFEF6A3B)
                  : (_streamFailed ? Colors.redAccent : Colors.greenAccent),
            ),
          ),

          Positioned(
            top: 14,
            right: 14,
            child: _pill(
              icon: Icons.link_rounded,
              text: 'Camera',
              accent: Colors.white70,
            ),
          ),

          Positioned(
            left: 14,
            right: 14,
            bottom: 14,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.44),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: Colors.white.withOpacity(0.07),
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.stream_rounded,
                    size: 18,
                    color: Colors.white.withOpacity(0.82),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      widget.demoMode
                          ? 'Preview mode is active'
                          : (_streamFailed
                              ? 'Waiting for robot camera stream'
                              : 'Connected to camera endpoint'),
                      style: const TextStyle(
                        fontSize: 12,
                        color: Colors.white70,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlaceholder({
    required String title,
    required String subtitle,
    required IconData icon,
    bool showSpinner = false,
  }) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Image.asset(
          'assets/images/robot_hero.png',
          fit: BoxFit.contain,
        ),
        Container(
          color: Colors.black.withOpacity(0.62),
        ),
        Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 22),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (showSpinner)
                  const SizedBox(
                    width: 28,
                    height: 28,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.4,
                    ),
                  )
                else
                  Icon(
                    icon,
                    size: 42,
                    color: AideColors.primary,
                  ),
                const SizedBox(height: 12),
                Text(
                  title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  subtitle,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    color: AideColors.textMuted,
                    fontSize: 12,
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _pill({
    required IconData icon,
    required String text,
    required Color accent,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.42),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(
          color: Colors.white.withOpacity(0.08),
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 15, color: accent),
          const SizedBox(width: 6),
          Text(
            text,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: accent,
            ),
          ),
        ],
      ),
    );
  }
}