import 'package:flutter/material.dart';
import '../models/app_role.dart';
import '../services/app_storage.dart';
import '../theme/app_theme.dart';
import '../widgets/aide_shell.dart';
import 'connect_screen.dart';

class AdminSetupScreen extends StatefulWidget {
  const AdminSetupScreen({super.key});

  @override
  State<AdminSetupScreen> createState() => _AdminSetupScreenState();
}

class _AdminSetupScreenState extends State<AdminSetupScreen> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();

  String _error = '';
  bool _busy = false;

  Future<void> _createAdmin() async {
    final adminName = _nameController.text.trim();
    final adminPassword = _passwordController.text.trim();
    final confirmPassword = _confirmPasswordController.text.trim();

    if (adminName.isEmpty || adminPassword.isEmpty || confirmPassword.isEmpty) {
      setState(() => _error = 'Please fill all fields.');
      return;
    }

    if (adminPassword != confirmPassword) {
      setState(() => _error = 'Passwords do not match.');
      return;
    }

    setState(() {
      _busy = true;
      _error = '';
    });

    await AppStorage.createAdmin(
      adminName: adminName,
      adminPassword: adminPassword,
    );

    if (!mounted) return;

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => ConnectScreen(
          role: AppRole.admin,
          username: adminName,
          profileKey: adminPassword,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _passwordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AideShell(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 8),
        child: Column(
          children: [
            const Spacer(),
            SizedBox(
              height: 180,
              child: Image.asset('assets/images/robot_hero.png'),
            ),
            const SizedBox(height: 14),
            const Text(
              'Initial Admin Setup',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            const Text(
              'Create the one admin account for this AIDE system.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AideColors.textMuted, height: 1.4),
            ),
            const Spacer(),
            AidePanel(
              radius: 28,
              color: AideColors.panel.withOpacity(0.92),
              child: Column(
                children: [
                  const AideSectionTitle('Admin Sign Up'),
                  const SizedBox(height: 16),
                  AideTextField(
                    controller: _nameController,
                    label: 'Admin Name',
                  ),
                  const SizedBox(height: 14),
                  AideTextField(
                    controller: _passwordController,
                    label: 'Admin Password',
                    obscureText: true,
                  ),
                  const SizedBox(height: 14),
                  AideTextField(
                    controller: _confirmPasswordController,
                    label: 'Confirm Password',
                    obscureText: true,
                  ),
                  if (_error.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    Text(
                      _error,
                      style: const TextStyle(color: AideColors.primarySoft),
                      textAlign: TextAlign.center,
                    ),
                  ],
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _busy ? null : _createAdmin,
                      child: Text(_busy ? 'Creating...' : 'Create Admin'),
                    ),
                  ),
                ],
              ),
            ),
            const Spacer(),
          ],
        ),
      ),
    );
  }
}