import 'package:flutter/material.dart';
import '../models/app_role.dart';
import '../services/app_storage.dart';
import '../theme/app_theme.dart';
import '../widgets/aide_shell.dart';
import 'connect_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.role});
  final AppRole role;

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _keyController = TextEditingController();

  String _error = '';
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _prefillUsername();
  }

  Future<void> _prefillUsername() async {
    final savedName = widget.role == AppRole.admin
        ? await AppStorage.getAdminName()
        : await AppStorage.getUserName();

    if (!mounted) return;
    _usernameController.text = savedName;
  }

  Future<void> _continue() async {
    final username = _usernameController.text.trim();
    final password = _keyController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      setState(() => _error = 'Please enter both username and password.');
      return;
    }

    if (widget.role == AppRole.user) {
      final hasUser = await AppStorage.hasUserCredentials();
      if (!hasUser) {
        setState(() {
          _error = 'User account has not been configured by admin yet.';
        });
        return;
      }
    }

    setState(() {
      _busy = true;
      _error = '';
    });

    final valid = await AppStorage.validateLogin(
      role: widget.role,
      username: username,
      password: password,
    );

    if (!mounted) return;

    if (!valid) {
      setState(() {
        _busy = false;
        _error = 'Invalid ${widget.role.label.toLowerCase()} name or password.';
      });
      return;
    }

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => ConnectScreen(
          role: widget.role,
          username: username,
          profileKey: password,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _keyController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AideShell(
      showBack: true,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 8),
        child: Column(
          children: [
            const Spacer(),
            SizedBox(
              height: 180,
              child: Image.asset('assets/images/robot_hero.png'),
            ),
            const SizedBox(height: 14),
            const Text(
              'Welcome To AIDE',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 8),
            AideChip(
              label: widget.role.label,
              color: widget.role == AppRole.admin
                  ? AideColors.primary
                  : AideColors.teal,
            ),
            const Spacer(),
            AidePanel(
              radius: 28,
              color: AideColors.panel.withOpacity(0.92),
              child: Column(
                children: [
                  AideSectionTitle('${widget.role.label} Login'),
                  const SizedBox(height: 16),
                  AideTextField(
                    controller: _usernameController,
                    label: 'Username',
                  ),
                  const SizedBox(height: 14),
                  AideTextField(
                    controller: _keyController,
                    label: 'Password',
                    obscureText: true,
                  ),
                  if (_error.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    Text(
                      _error,
                      style: const TextStyle(color: AideColors.primarySoft),
                      textAlign: TextAlign.center,
                    ),
                  ],
                  const SizedBox(height: 18),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: _busy ? null : _continue,
                      child: Text(_busy ? 'Checking...' : 'Login'),
                    ),
                  ),
                ],
              ),
            ),
            const Spacer(),
          ],
        ),
      ),
    );
  }
}