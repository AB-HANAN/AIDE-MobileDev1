import 'package:flutter/material.dart';
import '../models/app_role.dart';
import '../services/app_storage.dart';
import '../theme/app_theme.dart';
import '../widgets/aide_shell.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({
    super.key,
    required this.role,
  });

  final AppRole role;

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final TextEditingController _robotNameController = TextEditingController();
  final TextEditingController _adminNameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _adminPasswordController =
      TextEditingController();
  final TextEditingController _userNameController = TextEditingController();
  final TextEditingController _userPasswordController =
      TextEditingController();

  bool _loading = true;
  bool _saving = false;
  String _message = '';

  bool get _isAdmin => widget.role == AppRole.admin;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final robotName = await AppStorage.getRobotName();
    final adminName = await AppStorage.getAdminName();
    final adminPassword = await AppStorage.getAdminPassword();
    final userName = await AppStorage.getUserName();
    final userPassword = await AppStorage.getUserPassword();
    final phoneNumber = await AppStorage.getPhoneNumber();

    _robotNameController.text = robotName;
    _adminNameController.text = adminName;
    _adminPasswordController.text = adminPassword;
    _userNameController.text = userName;
    _userPasswordController.text = userPassword;
    _phoneController.text = phoneNumber;

    if (!mounted) return;
    setState(() {
      _loading = false;
    });
  }

  Future<void> _saveProfile() async {
    final robotName = _robotNameController.text.trim();
    final adminName = _adminNameController.text.trim();
    final adminPassword = _adminPasswordController.text.trim();
    final userName = _userNameController.text.trim();
    final userPassword = _userPasswordController.text.trim();
    final phoneNumber = _phoneController.text.trim();

    if (robotName.isEmpty) {
      setState(() {
        _message = 'Robot name cannot be empty.';
      });
      return;
    }

    if (adminName.isEmpty || adminPassword.isEmpty) {
      setState(() {
        _message = 'Admin name and password cannot be empty.';
      });
      return;
    }

    setState(() {
      _saving = true;
      _message = '';
    });

    try {
      await AppStorage.updateAdmin(
        adminName: adminName,
        adminPassword: adminPassword,
      );

      await AppStorage.updateProfileInfo(
        robotName: robotName,
        phoneNumber: phoneNumber,
      );

      if (userName.isNotEmpty || userPassword.isNotEmpty) {
        if (userName.isEmpty || userPassword.isEmpty) {
          if (!mounted) return;
          setState(() {
            _saving = false;
            _message = 'User name and user password must both be filled.';
          });
          return;
        }

        await AppStorage.updateUser(
          userName: userName,
          userPassword: userPassword,
        );
      }

      if (!mounted) return;
      setState(() {
        _saving = false;
        _message = 'Profile updated successfully.';
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _saving = false;
        _message = 'Failed to save profile: $e';
      });
    }
  }

  @override
  void dispose() {
    _robotNameController.dispose();
    _adminNameController.dispose();
    _phoneController.dispose();
    _adminPasswordController.dispose();
    _userNameController.dispose();
    _userPasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const AideShell(
        showBack: true,
        child: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    return AideShell(
      showBack: true,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 20),
        child: ListView(
          children: [
            Row(
              children: [
                Container(
                  width: 56,
                  height: 56,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Image.asset('assets/images/robot_hero.png'),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    _isAdmin ? 'Edit Profile' : 'Profile',
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 18),

            AidePanel(
              radius: 24,
              color: AideColors.panel.withOpacity(0.92),
              child: AbsorbPointer(
                absorbing: !_isAdmin,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const AideSectionTitle('System'),
                    const SizedBox(height: 12),
                    AideTextField(
                      controller: _robotNameController,
                      label: 'Robot Name',
                    ),
                    const SizedBox(height: 12),
                    AideTextField(
                      controller: _phoneController,
                      label: 'Phone Number',
                      keyboardType: TextInputType.phone,
                    ),

                    const SizedBox(height: 18),
                    const AideSectionTitle('Admin Credentials'),
                    const SizedBox(height: 12),
                    AideTextField(
                      controller: _adminNameController,
                      label: 'Admin Name',
                    ),
                    const SizedBox(height: 12),
                    AideTextField(
                      controller: _adminPasswordController,
                      label: 'Admin Password',
                      obscureText: true,
                    ),

                    const SizedBox(height: 18),
                    const AideSectionTitle('User Credentials'),
                    const SizedBox(height: 12),
                    AideTextField(
                      controller: _userNameController,
                      label: 'User Name',
                    ),
                    const SizedBox(height: 12),
                    AideTextField(
                      controller: _userPasswordController,
                      label: 'User Password',
                      obscureText: true,
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 16),

            if (_message.isNotEmpty)
              Text(
                _message,
                style: TextStyle(
                  color: _message.toLowerCase().contains('success')
                      ? Colors.greenAccent
                      : AideColors.primarySoft,
                ),
              ),

            const SizedBox(height: 12),

            if (_isAdmin)
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _saving ? null : _saveProfile,
                  child: Text(_saving ? 'Saving...' : 'Save Changes'),
                ),
              )
            else
              const Text(
                'Only admin can update profile details.',
                style: TextStyle(color: AideColors.textMuted),
              ),
          ],
        ),
      ),
    );
  }
}